package com.firebaseloginapp.AccountActivity;

import android.graphics.Color;
import android.os.AsyncTask;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.PolyUtil;

import java.io.IOException;
import java.util.HashMap;


public class GetDirectionsData extends AsyncTask<Object,String,String> {

    GoogleMap mMap;
    String url;
    String googleDirectionsData;
    String duration, distance;
    LatLng latLng;
    @Override
    protected String doInBackground(Object... objects) {
        mMap = (GoogleMap)objects[0];
        url = (String)objects[1];
        latLng = (LatLng)objects[2];



        com.firebaseloginapp.AccountActivity.DownloadUrl downloadUrl = new com.firebaseloginapp.AccountActivity.DownloadUrl();
        try {
            googleDirectionsData = downloadUrl.readUrl(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return googleDirectionsData;
    }

    @Override
    protected void onPostExecute(String s) {
        //duration
        HashMap<String,String> directionList1 = null;
        com.firebaseloginapp.AccountActivity.DataParser parser = new com.firebaseloginapp.AccountActivity.DataParser();
        directionList1 = parser.parseDirections1(s);
        duration =directionList1.get("duration");
        distance = directionList1.get("distance");
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("duration = "+duration);
        markerOptions.snippet("distance ="+distance);
        mMap.addMarker(markerOptions);

        //end

        String[] directionsList;
      // -  com.example.priyanka.mapsnearbyplaces.DataParser parser = new com.example.priyanka.mapsnearbyplaces.DataParser();
        directionsList = parser.parseDirections(s);
        displayDirection(directionsList);

    }

    public void displayDirection(String[] directionsList)
    {

        int count = directionsList.length;
        for(int i = 0;i<count;i++)
        {
            PolylineOptions options = new PolylineOptions();
            options.color(Color.RED);
            options.width(10);
            options.addAll(PolyUtil.decode(directionsList[i]));

            mMap.addPolyline(options);
        }
    }






}

