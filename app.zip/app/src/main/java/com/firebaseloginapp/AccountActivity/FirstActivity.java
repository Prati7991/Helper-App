package com.firebaseloginapp.AccountActivity;

/**
 * Created by priyanti on 2/10/17.
 */


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.firebaseloginapp.R;


public class FirstActivity extends AppCompatActivity
{

    public Button b1;
    public Button b2;
    public void init()
    {
        b1=(Button)findViewById(R.id.User);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent obj=new Intent(FirstActivity.this,LoginActivity.class);
                startActivity(obj);
            }
        });
       b2=(Button)findViewById(R.id.Supplier);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent obj1=new Intent(FirstActivity.this,LoginActivitySupplier.class);
                startActivity(obj1);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        init();

    }

}