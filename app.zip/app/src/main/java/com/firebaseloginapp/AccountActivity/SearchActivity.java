package com.firebaseloginapp.AccountActivity;

/**
 * Created by Pratiksha on 05-10-2017.
 */


import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.firebaseloginapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

public class SearchActivity extends AppCompatActivity {

    ImageButton b1,b2,b3,b4,b5,b6;

    Button btnmap,btnrating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
      b1 = (ImageButton) findViewById(R.id.mess);
        b2=(ImageButton) findViewById(R.id.houses);
        b3 = (ImageButton) findViewById(R.id.restaurant);
        b4=(ImageButton) findViewById(R.id.doctors);
        b5 = (ImageButton) findViewById(R.id.home_services);
        b6=(ImageButton) findViewById(R.id.repairs);
        btnmap=(Button)findViewById(R.id.map_view);
        btnrating=(Button)findViewById(R.id.btn_rating);

        //for mess
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b1 = (ImageButton) view;



                    Resources res = getResources();
                    InputStream is = res.openRawResource(R.raw.mess);
                    Scanner scanner=new Scanner(is);
                    StringBuilder builder=new StringBuilder();
                    while(scanner.hasNextLine())
                    {
                        builder.append(scanner.nextLine());


                    }
                    parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);




            }
        });
        //for houses on rent
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b2 = (ImageButton) view;



                Resources res = getResources();
                InputStream is = res.openRawResource(R.raw.houses);
                Scanner scanner=new Scanner(is);
                StringBuilder builder=new StringBuilder();
                while(scanner.hasNextLine())
                {
                    builder.append(scanner.nextLine());


                }
                parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);


            }
        });
        //for restaurants
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b3 = (ImageButton) view;



                Resources res = getResources();
                InputStream is = res.openRawResource(R.raw.restaurant);
                Scanner scanner=new Scanner(is);
                StringBuilder builder=new StringBuilder();
                while(scanner.hasNextLine())
                {
                    builder.append(scanner.nextLine());


                }
                parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);


            }
        });

        //for doctors
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b4 = (ImageButton) view;



                Resources res = getResources();
                InputStream is = res.openRawResource(R.raw.doctor);
                Scanner scanner=new Scanner(is);
                StringBuilder builder=new StringBuilder();
                while(scanner.hasNextLine())
                {
                    builder.append(scanner.nextLine());


                }
                parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);


            }
        });
            //for home services
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b5 = (ImageButton) view;



                Resources res = getResources();
                InputStream is = res.openRawResource(R.raw.home_service);
                Scanner scanner=new Scanner(is);
                StringBuilder builder=new StringBuilder();
                while(scanner.hasNextLine())
                {
                    builder.append(scanner.nextLine());


                }
                parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);


            }
        });
        //for repairs
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageButton b6 = (ImageButton) view;



                Resources res = getResources();
                InputStream is = res.openRawResource(R.raw.repair);
                Scanner scanner=new Scanner(is);
                StringBuilder builder=new StringBuilder();
                while(scanner.hasNextLine())
                {
                    builder.append(scanner.nextLine());


                }
                parseJson(builder.toString());

                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);


            }
        });
        btnmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                startActivity(new Intent(SearchActivity.this, MapsActivity.class));
            }
        });

        btnrating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                startActivity(new Intent(SearchActivity.this, Rating.class));
            }
        });





    }

    private void parseJson(String s)
    {
        TextView  txtDisplay=(TextView) findViewById(R.id.text_display);
        StringBuilder builder = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);

            JSONObject sup = root.getJSONObject("supplier-info");


            JSONArray sup1=sup.getJSONArray("supplier");
            for(int i=0;i< sup1.length();i++)
            {

                JSONObject obj=sup1.getJSONObject(i);
                
                builder.append("Name:")
                        .append(obj.getString("name")).append("\n");

                builder.append("Service Type: ")
                        .append(obj.getString("type")).append("\n");
                builder.append("Description: ")
                        .append(obj.getString("location")).append("\n");

                builder.append("Contact Details: ")
                        .append(obj.getString("contact")).append("\n\n")
                        .append("------------------------------------------------------");
            }


            JSONObject obj3=new JSONObject();





        }catch(JSONException e)
        {

            e.printStackTrace();
        }

        txtDisplay.setText(builder.toString());


    }


}
