package com.firebaseloginapp.AccountActivity;
/**
 * Created by priyanti on 2/10/17.
 */

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by Ravi Tamada on 07/10/16.
 * www.androidhive.info
 */

@IgnoreExtraProperties
public class Supplier {

    public String name;
    public String email;
    public String type;
    public String contact;
    public String description;
    public String address;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Supplier() {
    }

    public Supplier(String name, String email,String type,String contact,String location,String address) {
        this.name = name;
        this.email = email;
        this.type=type;
        this.contact=contact;
        this.description=location;
        this.address=address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getLocation() {
        return description;
    }

    public void setLocation(String location) {
        this.description = location;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}