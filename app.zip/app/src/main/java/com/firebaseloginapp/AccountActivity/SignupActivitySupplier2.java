package com.firebaseloginapp.AccountActivity;

/**
 * Created by Pratiksha on 10-10-2017.
 */


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.firebaseloginapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class SignupActivitySupplier2 extends AppCompatActivity  {

    private static final String TAG = MainActivitySupplier.class.getSimpleName();
    private TextView txtDetails;
    private EditText inputName, inputEmail,inputType,inputContact,inputDescription,inputAddress;
    private Button btnSave;
    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;

    private String supplierId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup2_supplier);

        // Displaying toolbar icon
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);


        inputName = (EditText) findViewById(R.id.name_s);
        inputEmail = (EditText) findViewById(R.id.email_s);
        inputType=(EditText) findViewById(R.id.type_s);
        inputContact=(EditText) findViewById(R.id.contact_s);
        inputDescription=(EditText) findViewById(R.id.location_s);
        inputAddress=(EditText) findViewById(R.id.address_s);
        btnSave = (Button) findViewById(R.id.btn_save_s);

        mFirebaseInstance = FirebaseDatabase.getInstance();

        // get reference to 'users' node
        mFirebaseDatabase = mFirebaseInstance.getReference("supplier");

        // store app title to 'app_title' node
        mFirebaseInstance.getReference("app_title").setValue("Realtime Database");

        // app_title change listener
        mFirebaseInstance.getReference("app_title").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.e(TAG, "App title updated");

                String appTitle = dataSnapshot.getValue(String.class);

                // update toolbar title
                getSupportActionBar().setTitle(appTitle);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.e(TAG, "Failed to read app title value.", error.toException());
            }
        });

        // Save / update the user
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = inputName.getText().toString();
                String email = inputEmail.getText().toString();
                String type = inputType.getText().toString();
                String contact = inputContact.getText().toString();
                String description = inputDescription.getText().toString();
                String address=inputAddress.getText().toString();
                // Check for already existed userId
                if (TextUtils.isEmpty(supplierId)) {
                    createSupplier(name, email,type,contact,description,address);
                }
            }
        });


    }



    /**
     * Creating new user node under 'users'
     */
    private void createSupplier(String name, String email, String type, String contact, String description, String address) {
        // TODO
        // In real apps this userId should be fetched
        // by implementing firebase auth
        if (TextUtils.isEmpty(supplierId)) {
            supplierId = mFirebaseDatabase.push().getKey();
        }

        Supplier supplier = new Supplier(name, email,type,contact,description,address);

        mFirebaseDatabase.child(supplierId).setValue(supplier);

        addSupplierChangeListener();
        startActivity(new Intent(SignupActivitySupplier2.this,MainActivitySupplier.class));
    }

    /**
     * User data change listener
     */
    private void addSupplierChangeListener() {
        // User data change listener
        mFirebaseDatabase.child(supplierId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Supplier supplier = dataSnapshot.getValue(Supplier.class);

                // Check for null
                if (supplier == null) {
                    Log.e(TAG, "Supplier data is null!");
                    return;
                }

                Log.e(TAG, "Supplier data is changed!" + supplier.name + ", " + supplier.email+","+supplier.type+" ,"+supplier.contact+","+supplier.description+","+supplier.address);



                // clear edit text
                inputEmail.setText("");
                inputName.setText("");
                inputType.setText("");
                inputContact.setText("");
                inputDescription.setText("");
                inputAddress.setText("");


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.e(TAG, "Failed to read supplier", error.toException());
            }
        });
    }


}