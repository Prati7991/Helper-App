package com.firebaseloginapp.AccountActivity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.firebaseloginapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivitySupplier extends AppCompatActivity {

    private EditText inputEmailS, inputPasswordS;
    private FirebaseAuth auth;
    private ProgressBar progressBarS;
    private Button btnSignupS, btnLoginS, btnResetS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_supplier);
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            startActivity(new Intent(LoginActivitySupplier.this, MainActivitySupplier.class));
            finish();
        }

        setContentView(R.layout.activity_login_supplier);
        inputEmailS = (EditText) findViewById(R.id.emails);
        inputPasswordS = (EditText) findViewById(R.id.passwords);
        progressBarS = (ProgressBar) findViewById(R.id.progressBars);
        btnSignupS = (Button) findViewById(R.id.btn_signups);
        btnLoginS = (Button) findViewById(R.id.btn_logins);
        btnResetS = (Button) findViewById(R.id.btn_reset_passwords);

        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();

        btnSignupS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivitySupplier.this, SignupActivitySupplier.class));
            }
        });

        btnResetS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivitySupplier.this, ResetPasswordActivitySupplier.class));
            }
        });

        btnLoginS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emails = inputEmailS.getText().toString();
                final String passwords = inputPasswordS.getText().toString();

                if (TextUtils.isEmpty(emails)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(passwords)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBarS.setVisibility(View.VISIBLE);

                //authenticate user
                auth.signInWithEmailAndPassword(emails, passwords)
                        .addOnCompleteListener(LoginActivitySupplier.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                progressBarS.setVisibility(View.GONE);
                                if (!task.isSuccessful()) {
                                    // there was an error
                                    if (passwords.length() < 6) {
                                        inputPasswordS.setError(getString(R.string.minimum_password));
                                    } else {
                                        Toast.makeText(LoginActivitySupplier.this, getString(R.string.auth_failed), Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    Intent intent = new Intent(LoginActivitySupplier.this, MainActivitySupplier.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });
            }
        });
    }
}

