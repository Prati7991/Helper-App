package com.firebaseloginapp.AccountActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.firebaseloginapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by Pratiksha on 10-10-2017.
 */

public class SignupActivity2 extends AppCompatActivity
{





        private static final String TAG = MainActivity.class.getSimpleName();
        private TextView txtDetails;
        private EditText inputName, inputEmail,inputType,inputContact,inputLocation,inputAddress;
        private Button btnSave;
        private DatabaseReference mFirebaseDatabase;
        private FirebaseDatabase mFirebaseInstance;

        private String userId;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_signup2);

            // Displaying toolbar icon
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setIcon(R.mipmap.ic_launcher);


            inputName = (EditText) findViewById(R.id.name_l);
            inputEmail = (EditText) findViewById(R.id.email_l);

            inputContact=(EditText) findViewById(R.id.contact_l);

            btnSave = (Button) findViewById(R.id.btn_save_l);

            mFirebaseInstance = FirebaseDatabase.getInstance();

            // get reference to 'users' node
            mFirebaseDatabase = mFirebaseInstance.getReference("user");

            // store app title to 'app_title' node
            mFirebaseInstance.getReference("app_title").setValue("Realtime Database");

            // app_title change listener
            mFirebaseInstance.getReference("app_title").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    Log.e(TAG, "App title updated");

                    String appTitle = dataSnapshot.getValue(String.class);

                    // update toolbar title
                    getSupportActionBar().setTitle(appTitle);
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.e(TAG, "Failed to read app title value.", error.toException());
                }
            });

            // Save / update the user
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String name = inputName.getText().toString();
                    String email = inputEmail.getText().toString();

                    String contact = inputContact.getText().toString();

                    // Check for already existed userId
                    if (TextUtils.isEmpty(userId)) {
                        createUser(name,email,contact);
                    }
                }
            });


        }



        /**
         * Creating new user node under 'users'
         */
        private void createUser(String name, String email, String contact) {
            // TODO
            // In real apps this userId should be fetched
            // by implementing firebase auth
            if (TextUtils.isEmpty(userId)) {
                userId = mFirebaseDatabase.push().getKey();
            }

            User user = new User(name, email,contact);

            mFirebaseDatabase.child(userId).setValue(user);

            addSupplierChangeListener();
            startActivity(new Intent(SignupActivity2.this,MainActivity.class));
        }

        /**
         * User data change listener
         */
        private void addSupplierChangeListener() {
            // User data change listener
            mFirebaseDatabase.child(userId).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    User user = dataSnapshot.getValue(User.class);

                    // Check for null
                    if (user == null) {
                        Log.e(TAG, "Supplier data is null!");
                        return;
                    }

                    Log.e(TAG, "Supplier data is changed!" + user.name + ", " + user.email+" ,"+user.contact);

                    // clear edit text
                    inputEmail.setText("");
                    inputName.setText("");

                    inputContact.setText("");



                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.e(TAG, "Failed to read supplier", error.toException());
                }
            });
        }


    }
